# JFiles Website

Open `index.html` in a browser to preview the site.

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`.
3. Open Settings → Pages.
4. Choose the main branch and root folder.
5. GitHub will provide your public website URL.

## Add songs
Edit the `songs` array near the bottom of `index.html`. Add original or properly licensed content.
